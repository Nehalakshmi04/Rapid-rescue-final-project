import { useState, useEffect } from 'react';
import { MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface LocationDisplayProps {
  className?: string;
}

const LocationDisplay = ({ className = "" }: LocationDisplayProps) => {
  const [location, setLocation] = useState('India');
  const [isDetecting, setIsDetecting] = useState(false);

  const getCurrentLocation = async () => {
    if (!navigator.geolocation) {
      console.log('Geolocation is not supported by this browser.');
      return;
    }

    setIsDetecting(true);
    
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        try {
          const { latitude, longitude } = position.coords;
          
          // Using a reverse geocoding service (OpenStreetMap Nominatim)
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=10&addressdetails=1`
          );
          
          if (response.ok) {
            const data = await response.json();
            const city = data.address?.city || data.address?.town || data.address?.village;
            const state = data.address?.state;
            const country = data.address?.country;
            
            let locationString = '';
            if (city && state) {
              locationString = `${city}, ${state}`;
            } else if (city) {
              locationString = city;
            } else if (state) {
              locationString = state;
            } else if (country) {
              locationString = country;
            } else {
              locationString = 'Current Location';
            }
            
            setLocation(locationString);
          } else {
            setLocation('Current Location');
          }
        } catch (error) {
          console.error('Error getting location details:', error);
          setLocation('Current Location');
        } finally {
          setIsDetecting(false);
        }
      },
      (error) => {
        console.error('Error getting position:', error);
        setIsDetecting(false);
        // Keep showing India if location access fails
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000 // 5 minutes
      }
    );
  };

  return (
    <Button
      variant="ghost"
      onClick={getCurrentLocation}
      disabled={isDetecting}
      className={`flex items-center space-x-2 ${className}`}
    >
      <MapPin className={`w-4 h-4 text-gray-500 ${isDetecting ? 'animate-pulse' : ''}`} />
      <span className="text-sm text-gray-600 hidden sm:inline">
        {isDetecting ? 'Detecting...' : location}
      </span>
    </Button>
  );
};

export default LocationDisplay;
