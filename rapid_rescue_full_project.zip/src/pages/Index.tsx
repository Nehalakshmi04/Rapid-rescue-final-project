import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Phone, Mail, Shield, Users, Clock, MapPin, Heart, Zap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import LocationDisplay from '@/components/LocationDisplay';

const Index = () => {
  const navigate = useNavigate();
  const [isEmergency, setIsEmergency] = useState(false);

  const handleEmergencyClick = () => {
    setIsEmergency(true);
    // In a real app, this would trigger emergency protocols
    setTimeout(() => {
      navigate('/help-seeker');
    }, 1000);
  };

  const stats = [
    { label: 'Lives Saved', value: '2,847', icon: Heart },
    { label: 'Active Volunteers', value: '15,642', icon: Users },
    { label: 'Average Response', value: '3.2 min', icon: Clock },
    { label: 'Cities Covered', value: '127', icon: MapPin }
  ];

  const services = [
    { name: 'Emergency Response', description: 'Immediate help for accidents and emergencies', color: 'bg-red-500' },
    { name: 'Elderly Care', description: '24/7 support for senior citizens', color: 'bg-blue-500' },
    { name: 'Women Safety', description: 'Dedicated safety network for women', color: 'bg-purple-500' },
    { name: 'Mental Health', description: 'Professional counseling and support', color: 'bg-green-500' },
    { name: 'Legal Aid', description: 'Affordable legal consultation', color: 'bg-yellow-500' },
    { name: 'Financial Advisory', description: 'Expert financial guidance', color: 'bg-indigo-500' },
    { name: 'Weekend Tutoring', description: 'Educational support by volunteers', color: 'bg-pink-500' },
    { name: 'Fire Emergency', description: 'Rapid fire response coordination', color: 'bg-orange-500' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">Rapid Rescue</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" onClick={() => navigate('/login')}>
                Sign In
              </Button>
              <Button onClick={() => navigate('/signup')} className="bg-red-600 hover:bg-red-700">
                Join Now
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            Help is Just a <span className="text-red-600">Tap Away</span>
          </h2>
          <p className="text-xl text-gray-600 mb-12 max-w-3xl mx-auto">
            Connect with verified volunteers and professional services in your community. 
            Whether it's an emergency or you need support, Rapid Rescue is here 24/7.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16">
            <Button 
              size="lg"
              className={`text-lg px-8 py-4 rounded-full transition-all duration-300 ${
                isEmergency 
                  ? 'bg-red-700 animate-pulse' 
                  : 'bg-red-600 hover:bg-red-700 hover:scale-105'
              }`}
              onClick={handleEmergencyClick}
            >
              🚨 EMERGENCY HELP
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="text-lg px-8 py-4 rounded-full hover:scale-105 transition-all duration-300"
              onClick={() => navigate('/help-seeker')}
            >
              Browse Services
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
            {stats.map((stat, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardContent className="p-6 text-center">
                  <stat.icon className="w-8 h-8 text-red-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">Our Services</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer"
                    onClick={() => navigate('/help-seeker')}>
                <CardHeader className="pb-4">
                  <div className={`w-12 h-12 ${service.color} rounded-lg flex items-center justify-center mb-4`}>
                    <Shield className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-lg">{service.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>{service.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-red-600 to-red-700">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-3xl font-bold text-white mb-6">Ready to Make a Difference?</h3>
          <p className="text-xl text-red-100 mb-8">
            Join thousands of volunteers helping their communities or access support when you need it most.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg"
              variant="secondary"
              className="text-lg px-8 py-4 rounded-full"
              onClick={() => navigate('/signup')}
            >
              Become a Volunteer
            </Button>
            <Button 
              size="lg"
              variant="outline"
              className="text-lg px-8 py-4 rounded-full bg-transparent border-white text-white hover:bg-white hover:text-red-600"
              onClick={() => navigate('/help-seeker')}
            >
              Get Help Now
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Zap className="w-6 h-6 text-red-500" />
                <span className="text-xl font-bold">Rapid Rescue</span>
              </div>
              <p className="text-gray-400">Building safer, more connected communities through technology and compassion.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-gray-400">
                <li className="cursor-pointer hover:text-white" onClick={() => navigate('/help-seeker')}>Emergency Response</li>
                <li className="cursor-pointer hover:text-white" onClick={() => navigate('/signup')}>Volunteer Network</li>
                <li className="cursor-pointer hover:text-white" onClick={() => navigate('/help-seeker')}>Community Support</li>
                <li className="cursor-pointer hover:text-white" onClick={() => navigate('/help-seeker')}>Professional Services</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Help Center</li>
                <li>Safety Guidelines</li>
                <li>Contact Us</li>
                <li>Report Issue</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Emergency Contacts</h4>
              <div className="space-y-2 text-gray-400">
                <div className="flex items-center space-x-2">
                  <Phone className="w-4 h-4" />
                  <span>Emergency: 911</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Mail className="w-4 h-4" />
                  <span>help@rapidrescue.com</span>
                </div>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Rapid Rescue. All rights reserved. Built with ❤️ for safer communities.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
