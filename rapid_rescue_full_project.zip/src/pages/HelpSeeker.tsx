import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Phone, 
  Shield, 
  Users, 
  Heart, 
  Brain, 
  Scale, 
  DollarSign, 
  GraduationCap,
  MapPin,
  Clock,
  AlertTriangle,
  Search,
  ArrowLeft,
  Zap
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import LocationDisplay from '@/components/LocationDisplay';

const HelpSeeker = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const emergencyServices = [
    {
      id: 'accident',
      title: 'Accident Emergency',
      description: 'Immediate response for accidents and injuries',
      icon: AlertTriangle,
      color: 'bg-red-500',
      urgent: true,
      responseTime: '2-5 min'
    },
    {
      id: 'fire',
      title: 'Fire Emergency',
      description: 'Fire safety and emergency response',
      icon: AlertTriangle,
      color: 'bg-orange-500',
      urgent: true,
      responseTime: '3-7 min'
    }
  ];

  const supportServices = [
    {
      id: 'elderly',
      title: 'Elderly Care',
      description: 'Support and assistance for senior citizens',
      icon: Heart,
      color: 'bg-blue-500',
      urgent: false,
      responseTime: '15-30 min'
    },
    {
      id: 'women-safety',
      title: 'Women Safety',
      description: 'Safety support and assistance for women',
      icon: Shield,
      color: 'bg-purple-500',
      urgent: false,
      responseTime: '5-15 min'
    },
    {
      id: 'mental-health',
      title: 'Mental Health Support',
      description: 'Professional counseling and emotional support',
      icon: Brain,
      color: 'bg-green-500',
      urgent: false,
      responseTime: '10-20 min'
    },
    {
      id: 'legal',
      title: 'Legal Aid',
      description: 'Affordable legal consultation and advice',
      icon: Scale,
      color: 'bg-indigo-500',
      urgent: false,
      responseTime: '30-60 min'
    },
    {
      id: 'financial',
      title: 'Financial Advisory',
      description: 'Expert financial guidance and planning',
      icon: DollarSign,
      color: 'bg-yellow-500',
      urgent: false,
      responseTime: '20-45 min'
    },
    {
      id: 'tutoring',
      title: 'Weekend Tutoring',
      description: 'Educational support by volunteer teachers',
      icon: GraduationCap,
      color: 'bg-pink-500',
      urgent: false,
      responseTime: 'Scheduled'
    }
  ];

  const handleEmergencyRequest = (serviceId: string) => {
    navigate(`/emergency-request/${serviceId}`);
  };

  const handleServiceRequest = (serviceId: string) => {
    navigate(`/service-request/${serviceId}`);
  };

  const filteredServices = [...emergencyServices, ...supportServices].filter(service =>
    service.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    service.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Button 
              variant="ghost" 
              onClick={() => navigate('/domain-selection')}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold text-gray-900">Rapid Rescue</h1>
            </div>
            <LocationDisplay />
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-4 sm:p-6">
        {/* Hero Section */}
        <div className="text-center mb-6 sm:mb-8">
          <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4">How can we help you today?</h2>
          <p className="text-base sm:text-lg text-gray-600 max-w-2xl mx-auto mb-4 sm:mb-6">
            Get immediate assistance from our network of verified volunteers and professionals.
          </p>
          
          {/* Search Bar */}
          <div className="max-w-md mx-auto relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="Search for help..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-3 text-lg"
            />
          </div>
        </div>

        {/* Emergency Services */}
        <div className="mb-8 sm:mb-12">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 sm:mb-6 space-y-2 sm:space-y-0">
            <h3 className="text-xl sm:text-2xl font-bold text-gray-900 flex items-center space-x-2">
              <AlertTriangle className="w-5 h-5 sm:w-6 sm:h-6 text-red-500" />
              <span>Emergency Services</span>
            </h3>
            <Badge variant="destructive" className="animate-pulse w-fit">
              URGENT
            </Badge>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 mb-6 sm:mb-8">
            {emergencyServices.filter(service =>
              service.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
              service.description.toLowerCase().includes(searchQuery.toLowerCase())
            ).map((service) => (
              <Card key={service.id} className="border-2 border-red-200 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between">
                    <div className={`w-10 h-10 sm:w-12 sm:h-12 ${service.color} rounded-lg flex items-center justify-center`}>
                      <service.icon className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                    </div>
                    <Badge variant="destructive" className="animate-pulse text-xs">
                      EMERGENCY
                    </Badge>
                  </div>
                  <CardTitle className="text-lg sm:text-xl">{service.title}</CardTitle>
                  <CardDescription className="text-sm sm:text-base">{service.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 space-y-2 sm:space-y-0">
                    <div className="flex items-center space-x-2 text-xs sm:text-sm text-gray-600">
                      <Clock className="w-4 h-4" />
                      <span>Response: {service.responseTime}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-xs sm:text-sm text-green-600">
                      <Users className="w-4 h-4" />
                      <span>47 volunteers nearby</span>
                    </div>
                  </div>
                  <Button 
                    className="w-full bg-red-600 hover:bg-red-700 text-base sm:text-lg py-4 sm:py-6 font-semibold"
                    onClick={() => handleEmergencyRequest(service.id)}
                  >
                    🚨 Request Emergency Help
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Support Services */}
        <div>
          <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6 flex items-center space-x-2">
            <Heart className="w-5 h-5 sm:w-6 sm:h-6 text-blue-500" />
            <span>Community Support Services</span>
          </h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {supportServices.filter(service =>
              service.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
              service.description.toLowerCase().includes(searchQuery.toLowerCase())
            ).map((service) => (
              <Card key={service.id} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                <CardHeader className="pb-4">
                  <div className={`w-10 h-10 sm:w-12 sm:h-12 ${service.color} rounded-lg flex items-center justify-center mb-4`}>
                    <service.icon className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                  </div>
                  <CardTitle className="text-base sm:text-lg">{service.title}</CardTitle>
                  <CardDescription className="text-sm">{service.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs sm:text-sm">
                      <div className="flex items-center space-x-2 text-gray-600">
                        <Clock className="w-4 h-4" />
                        <span>{service.responseTime}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-green-600">
                        <Users className="w-4 h-4" />
                        <span>Available</span>
                      </div>
                    </div>
                    
                    <Button 
                      className="w-full bg-blue-600 hover:bg-blue-700 py-3 font-medium"
                      onClick={() => handleServiceRequest(service.id)}
                    >
                      Request Help
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Quick Contact */}
        <div className="mt-12 sm:mt-16 bg-white rounded-lg shadow-xl p-6 sm:p-8 text-center">
          <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4">Need Immediate Assistance?</h3>
          <p className="text-gray-600 mb-6">If this is a life-threatening emergency, please call emergency services directly.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="outline" className="flex items-center space-x-2">
              <Phone className="w-5 h-5" />
              <span>Call 911</span>
            </Button>
            <Button size="lg" className="bg-red-600 hover:bg-red-700 flex items-center space-x-2">
              <AlertTriangle className="w-5 h-5" />
              <span>Emergency Chat</span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HelpSeeker;
