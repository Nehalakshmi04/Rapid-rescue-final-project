
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Heart, Shield, CheckCircle, Clock, ArrowLeft, Zap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const DomainSelection = () => {
  const navigate = useNavigate();

  const handleDomainSelect = (domain: string) => {
    if (domain === 'volunteer') {
      navigate('/volunteer-verification');
    } else {
      navigate('/help-seeker');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Button 
              variant="ghost" 
              onClick={() => navigate('/')}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold text-gray-900">Rapid Rescue</h1>
            </div>
            <div></div>
          </div>
        </div>
      </header>

      <div className="flex items-center justify-center min-h-[calc(100vh-4rem)] p-4">
        <div className="w-full max-w-4xl">
          {/* Header */}
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Choose Your Role</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Are you here to help others or seeking assistance? Select your role to continue.
            </p>
          </div>

          {/* Role Cards */}
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Volunteer Card */}
            <Card className="border-0 shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 cursor-pointer group">
              <CardHeader className="text-center pb-6">
                <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <Users className="w-10 h-10 text-white" />
                </div>
                <CardTitle className="text-2xl font-bold text-gray-900">Volunteer</CardTitle>
                <CardDescription className="text-lg text-gray-600">
                  Join our verified community of helpers
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-500 mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-gray-900">Verification Required</p>
                      <p className="text-sm text-gray-600">ID verification for safety and trust</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <Shield className="w-5 h-5 text-blue-500 mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-gray-900">Background Check</p>
                      <p className="text-sm text-gray-600">Comprehensive screening process</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <Heart className="w-5 h-5 text-red-500 mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-gray-900">Make a Difference</p>
                      <p className="text-sm text-gray-600">Help people in your community</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-2">What you can do:</h4>
                  <ul className="text-sm text-blue-700 space-y-1">
                    <li>• Respond to emergency calls</li>
                    <li>• Provide specialized services</li>
                    <li>• Offer tutoring and mentoring</li>
                    <li>• Support vulnerable community members</li>
                  </ul>
                </div>

                <Button 
                  className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-6"
                  onClick={() => handleDomainSelect('volunteer')}
                >
                  Become a Volunteer
                </Button>
              </CardContent>
            </Card>

            {/* Help Seeker Card */}
            <Card className="border-0 shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 cursor-pointer group">
              <CardHeader className="text-center pb-6">
                <div className="w-20 h-20 bg-red-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <Heart className="w-10 h-10 text-white" />
                </div>
                <CardTitle className="text-2xl font-bold text-gray-900">Seek Help</CardTitle>
                <CardDescription className="text-lg text-gray-600">
                  Get immediate assistance when you need it
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <Clock className="w-5 h-5 text-green-500 mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-gray-900">Immediate Access</p>
                      <p className="text-sm text-gray-600">No registration required for emergencies</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <Shield className="w-5 h-5 text-blue-500 mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-gray-900">Verified Helpers</p>
                      <p className="text-sm text-gray-600">All volunteers are background checked</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <Users className="w-5 h-5 text-purple-500 mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-gray-900">Community Support</p>
                      <p className="text-sm text-gray-600">Access to wide range of services</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-red-50 p-4 rounded-lg">
                  <h4 className="font-medium text-red-900 mb-2">Available services:</h4>
                  <ul className="text-sm text-red-700 space-y-1">
                    <li>• Emergency response & accidents</li>
                    <li>• Mental health support</li>
                    <li>• Legal and financial advice</li>
                    <li>• Elderly care and women safety</li>
                  </ul>
                </div>

                <Button 
                  className="w-full bg-red-600 hover:bg-red-700 text-lg py-6"
                  onClick={() => handleDomainSelect('help-seeker')}
                >
                  Get Help Now
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Additional Info */}
          <div className="text-center mt-12">
            <p className="text-gray-600">
              Need help deciding? <Button variant="link" className="text-red-600 p-0">Contact our support team</Button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DomainSelection;
