
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  ArrowLeft, 
  Clock, 
  Phone, 
  MessageSquare, 
  User, 
  Star,
  Navigation,
  Zap
} from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import LocationDisplay from '@/components/LocationDisplay';

const RequestTracking = () => {
  const navigate = useNavigate();
  const { serviceId } = useParams();
  const [progress, setProgress] = useState(25);
  const [status, setStatus] = useState('searching');
  const [volunteer, setVolunteer] = useState(null);
  const [estimatedTime, setEstimatedTime] = useState('5-8 min');

  // Simulate volunteer assignment and progress
  useEffect(() => {
    const timer1 = setTimeout(() => {
      setStatus('assigned');
      setProgress(50);
      setVolunteer({
        name: 'Dr. Sarah Johnson',
        rating: 4.9,
        specialization: 'Emergency Medical Response',
        phone: '+1 (555) 123-4567',
        distance: '2.3 km away',
        eta: '6 minutes'
      });
      setEstimatedTime('6 min');
    }, 3000);

    const timer2 = setTimeout(() => {
      setStatus('en-route');
      setProgress(75);
      setEstimatedTime('3 min');
    }, 6000);

    const timer3 = setTimeout(() => {
      setStatus('arrived');
      setProgress(100);
      setEstimatedTime('Arrived');
    }, 12000);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, []);

  const getStatusConfig = () => {
    switch (status) {
      case 'searching':
        return {
          title: 'Finding Nearby Volunteers',
          description: 'We\'re connecting you with available volunteers in your area',
          color: 'bg-yellow-500',
          icon: '🔍'
        };
      case 'assigned':
        return {
          title: 'Volunteer Assigned',
          description: 'A qualified volunteer has accepted your request',
          color: 'bg-blue-500',
          icon: '✅'
        };
      case 'en-route':
        return {
          title: 'Volunteer En Route',
          description: 'Your volunteer is on the way to your location',
          color: 'bg-orange-500',
          icon: '🚗'
        };
      case 'arrived':
        return {
          title: 'Volunteer Arrived',
          description: 'Your volunteer has reached your location',
          color: 'bg-green-500',
          icon: '🎯'
        };
      default:
        return {
          title: 'Processing Request',
          description: 'Please wait...',
          color: 'bg-gray-500',
          icon: '⏳'
        };
    }
  };

  const statusConfig = getStatusConfig();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Button 
              variant="ghost" 
              onClick={() => navigate('/help-seeker')}
              className="flex items-center space-x-2"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Cancel Request</span>
            </Button>
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold text-gray-900">Request Tracking</h1>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="destructive" className="animate-pulse">
                LIVE
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
        {/* Status Card */}
        <Card className="border-0 shadow-xl">
          <CardHeader className="text-center pb-4">
            <div className={`w-16 h-16 ${statusConfig.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
              <span className="text-2xl">{statusConfig.icon}</span>
            </div>
            <CardTitle className="text-2xl">{statusConfig.title}</CardTitle>
            <p className="text-gray-600">{statusConfig.description}</p>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between text-sm">
                <span>Progress</span>
                <span className="font-semibold">{progress}%</span>
              </div>
              <Progress value={progress} className="h-3" />
              <div className="flex items-center justify-center space-x-2 text-lg font-semibold">
                <Clock className="w-5 h-5 text-blue-500" />
                <span>ETA: {estimatedTime}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Service Info */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Request Details</span>
              <LocationDisplay className="text-sm" />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-600">Service Type</p>
                <p className="font-semibold capitalize">{serviceId?.replace('-', ' ') || 'Emergency Help'}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Location</p>
                <p className="font-semibold">Current Location, India</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Request Time</p>
                <p className="font-semibold">{new Date().toLocaleTimeString()}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Priority</p>
                <Badge variant="destructive">High</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Volunteer Info */}
        {volunteer && (
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <User className="w-5 h-5 text-blue-500" />
                <span>Your Volunteer</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-start space-x-4">
                <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center">
                  <User className="w-8 h-8 text-white" />
                </div>
                <div className="flex-1 space-y-3">
                  <div>
                    <h3 className="font-semibold text-lg">{volunteer.name}</h3>
                    <p className="text-gray-600">{volunteer.specialization}</p>
                  </div>
                  
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="font-semibold">{volunteer.rating}</span>
                    <span className="text-gray-600">(247 reviews)</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
                    <div className="flex items-center space-x-2">
                      <Navigation className="w-4 h-4 text-gray-500" />
                      <span>{volunteer.distance}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="w-4 h-4 text-gray-500" />
                      <span>ETA: {volunteer.eta}</span>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3 pt-2">
                    <Button 
                      className="flex-1 bg-green-600 hover:bg-green-700"
                      onClick={() => window.open(`tel:${volunteer.phone}`)}
                    >
                      <Phone className="w-4 h-4 mr-2" />
                      Call Volunteer
                    </Button>
                    <Button 
                      variant="outline" 
                      className="flex-1"
                    >
                      <MessageSquare className="w-4 h-4 mr-2" />
                      Message
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Map Placeholder */}
        <Card className="border-0 shadow-lg">
          <CardContent className="p-0">
            <div className="h-64 sm:h-80 bg-gradient-to-br from-blue-100 to-green-100 rounded-lg flex items-center justify-center relative overflow-hidden">
              <div className="text-center space-y-2">
                <LocationDisplay className="text-blue-500 font-medium text-lg" />
                <p className="text-sm text-gray-500">Live Location Tracking</p>
                <p className="text-xs text-gray-400">Map integration coming soon</p>
              </div>
              
              {/* Animated dots to simulate tracking */}
              <div className="absolute top-4 left-4">
                <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                <p className="text-xs text-gray-600 mt-1">You</p>
              </div>
              
              {volunteer && (
                <div className="absolute bottom-4 right-4">
                  <div className="w-3 h-3 bg-blue-500 rounded-full animate-bounce"></div>
                  <p className="text-xs text-gray-600 mt-1">Volunteer</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Emergency Contact */}
        <Card className="border-2 border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="text-center space-y-3">
              <h3 className="font-semibold text-red-700">Emergency Contact</h3>
              <p className="text-sm text-red-600">
                If this is a life-threatening emergency, call emergency services immediately
              </p>
              <Button 
                variant="destructive" 
                size="lg"
                onClick={() => window.open('tel:911')}
                className="w-full sm:w-auto"
              >
                <Phone className="w-4 h-4 mr-2" />
                Call 911
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default RequestTracking;
