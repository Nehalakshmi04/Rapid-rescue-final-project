const mongoose = require('mongoose');

const RescueSchema = new mongoose.Schema({
  name: String,
  location: String,
  status: {
    type: String,
    default: 'pending',
  },
  timestamp: {
    type: Date,
    default: Date.now,
  }
});

module.exports = mongoose.model('Rescue', RescueSchema);
