const express = require('express');
const router = express.Router();
const Rescue = require('../models/Rescue');

router.post('/', async (req, res) => {
  try {
    const rescue = new Rescue(req.body);
    await rescue.save();
    res.status(201).send(rescue);
  } catch (err) {
    res.status(400).send(err);
  }
});

router.get('/', async (req, res) => {
  const rescues = await Rescue.find();
  res.send(rescues);
});

router.patch('/:id/complete', async (req, res) => {
  const { id } = req.params;
  try {
    const updated = await Rescue.findByIdAndUpdate(id, { status: 'completed' }, { new: true });
    res.send(updated);
  } catch (err) {
    res.status(500).send(err);
  }
});

module.exports = router;
